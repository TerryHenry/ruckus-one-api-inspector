(() => {
  const MAX_BODY_KEY = 'ruckusApiInspectorMaxBodyV1';
  let enabled = false, maxBody;
  const post = () => window.postMessage({ __ruckusApiInspectorCaptureState: true, enabled, maxBody }, '*');
  const applyCaptureState = value => { enabled = !!value; post(); };
  chrome.runtime.onMessage.addListener(message => { if (message?.type === 'SET_PAGE_CAPTURE') applyCaptureState(message.enabled); });
  try { chrome.storage.local.get({ [MAX_BODY_KEY]: null }, data => { if (!chrome.runtime.lastError && data[MAX_BODY_KEY]) { maxBody = Number(data[MAX_BODY_KEY]); post(); } }); } catch {}
  try { chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes[MAX_BODY_KEY]) { maxBody = Number(changes[MAX_BODY_KEY].newValue) || undefined; post(); } }); } catch {}
  try { chrome.runtime.sendMessage({ type: 'GET_CAPTURE_STATUS' }, response => { if (!chrome.runtime.lastError) applyCaptureState(response?.enabled); }); } catch {}
  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.__ruckusApiInspector !== true || !event.data.record) return;
    try { chrome.runtime.sendMessage({ type: 'API_CAPTURE', record: event.data.record }); } catch {}
  });
})();
