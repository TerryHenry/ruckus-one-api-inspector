# RUCKUS One API Inspector v1.7.0

Chrome/Edge Manifest V3 side-panel extension for inspecting RUCKUS One browser API traffic.

## New in v1.5.0
- API coverage analysis compares retained captured requests with the active API schema.
- Shows observed/matched operations, captured endpoints that did not match the schema, and documented operations not observed in the current capture history.
- Upload a tenant-specific OpenAPI JSON file or a ZIP containing an OpenAPI JSON file. The uploaded schema is normalized into a compact local index and saved in browser extension storage.
- Restore the bundled schema at any time.
- Export a JSON coverage report.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions` or `edge://extensions`.
3. Enable Developer mode and choose **Load unpacked**.
4. Select the `ruckus_one_api_inspector` folder.
5. Reload your RUCKUS One tab and open the side panel.

## Tenant schema upload
Open **API Catalog** → **API Coverage & Tenant Schema**. Enter a tenant/schema label, click **Upload tenant API schema**, and select an OpenAPI JSON file or a ZIP containing one. The schema is processed and stored locally in this browser. Uploading a new schema replaces the active schema index; it does not contact the tenant or fetch the schema automatically. To revert, click **Use bundled schema**.

## Coverage interpretation
Coverage is calculated from the currently retained capture history. An operation listed as not observed is not necessarily unused or unavailable; it simply was not captured. Unmatched paths can be undocumented endpoints, version-specific routes, URL-prefix differences, or normalization limitations. Review results before treating them as definitive.

## Privacy
Schema parsing and coverage analysis run locally in the browser. Captured traffic may contain sensitive tenant/resource information; inspect exports before sharing.


## v1.6.0 — Multi-tenant schema profiles

- Save multiple OpenAPI schemas as named local profiles.
- Uploaded schemas are automatically saved as profiles.
- Activate a saved profile without uploading it again.
- Compare two profiles by HTTP method + OpenAPI path. Reports list added, removed, changed, and unchanged operations, including definition changes to summaries, descriptions, operation IDs, parameters, body fields, and response-code lists.
- Export schema comparisons as JSON.
- Profiles persist in `chrome.storage.local`; the extension requests `unlimitedStorage` to support larger schema collections.

Schema comparison is structural and path-based. It does not establish whether an operation is enabled for a live tenant, and it does not call RUCKUS One APIs. Keep tenant schemas local and review them before sharing.


## v1.7.0 — Tenant capability matrix

- Adds a matrix combining active-schema documentation, live capture observations, response status codes, and optional differences against a selected saved baseline profile.
- Highlights documented operations that have not appeared in retained capture history, captured endpoints that do not match the active schema, and observed operations with HTTP errors or no captured response.
- Shows summary counts for documented, observed, undocumented, investigation, and added/changed operations.
- Search the matrix and export the complete evidence set to JSON. The on-screen table is capped at 300 rows for responsiveness.
- Matrix results are evidence from local schema and capture history only; they do not prove tenant entitlements or feature availability.

All v1.6.0 schema profile management and comparison features remain included.


## v1.8.0
- Added a **Show API call descriptions** toggle in the Live Traffic controls. Turn it off to hide the plain-language endpoint explanations and give the request timeline more room; turn it back on any time.
- The setting is saved locally and persists across panel closes and extension updates.


## v1.9.0 — API Workbench & Workflow Discovery
- Smart API Explorer for sanitized captured request/response details, observed response fields, endpoint copying, and sanitized cURL/Python templates.
- Troubleshooting and performance summary with average and p95 latency, failures, slow calls, repeated endpoints, and write-like operation cautions.
- Captured response structural diff to identify added, removed, and type-changed JSON fields.
- Workflow Discovery groups calls into likely sequences using a 90-second inactivity gap, collapses repeated endpoints for readability, and exports a workflow map. 
- Safe request validation / dry-run preview in the recipe builder. It validates URL, query JSON, and JSON body and **never sends API requests**.
- Partner support bundle exports sanitized capture records, endpoint summary, notes, discovered workflow data. Review tenant/customer data before sharing.
- All prior schema profiles, capability matrix, description toggle, projects, recipes, and backup features retained.


## v2.0.0 — Workflow Studio

- Save named discovery sets in browser-local extension storage and reload them later.
- Export a Markdown workflow guide for partner enablement, troubleshooting runbooks, and support notes.
- Workflow cards show observed step counts, status, duration, and write-like method indicators.
- Copy a workflow's ordered step list or send it to recipe notes.
- Saved discovery sets are local to this browser profile and can be removed from the Workflow Studio.
- Workflow discovery remains heuristic: a 90-second inactivity gap groups requests, duplicate endpoints are collapsed in the displayed sequence, and timing does not prove causality or dependencies.
- Existing capture, schema profiles, API catalog, capability matrix, explorer, troubleshooting, response diff, recipes, and project/backup functions are retained.


## v2.1.0 — API Intelligence

- Added an Interactive API Dependency Mapper view. It groups captured operations and looks for response identifier values that appear in later request URLs or bodies.
- Separates direct identifier-handoff candidates from weaker temporal sequence clues. Neither is presented as a confirmed server-side dependency.
- Added Field Intelligence for observed request/response JSON paths, types, frequency, endpoint coverage, and approximate schema-name matching.
- Field values are not included in the on-screen inventory or intelligence export; only field names and structural metadata are exported.
- Added search/filter controls and JSON export. All analysis is local and derived from retained captured traffic.


## v2.2.0 — Regression & Performance Baselines

- Save named metadata-only baselines from the current filtered capture view.
- Compare later captures for added/missing endpoints, status distribution changes, request-count changes, error-count changes, sequence differences, and latency regressions.
- Latency regression flags require average latency to rise by at least 100 ms and 25%; this is a heuristic, not proof of a service regression.
- Export a JSON regression report.
- Baselines persist locally and are included in full backups. Baselines store endpoint metadata and timing/status metrics only, not request/response bodies or headers.
- Regression comparisons are observational and do not replay API calls.

## v2.3.0 — Documentation Library & Partner Lab Mode

- **Documentation Library:** generate a local endpoint reference from currently filtered captured traffic, with observed status counts, latency summaries, JSON field paths/types, workflow discoveries, and saved recipe metadata. Export Markdown or JSON. Payload values are not included in the generated reference.
- **Partner Lab Mode:** generate a student guide, instructor guide, or combined Markdown lab from current discovered workflows or saved discovery sets. Includes learning objectives, task checkpoints, observed sample status/latency, instructor notes, suggested timing, and evidence-handling guidance.
- **Persistence:** documentation snapshots and saved labs are stored in browser-local storage and included in full backup/restore.
- **Caveat:** generated documentation and lab materials are evidence summaries, not authoritative API specifications. Validate endpoint descriptions, expected behavior, and all instructions against an approved test tenant before delivery.


## v2.4.0 — Troubleshooting Correlation Engine

- Adds Incident Correlation to the Troubleshooting & Performance panel.
- Correlates failed calls, generic HTTP status clues, repeated endpoint failures, within-endpoint latency outliers, empty query/list results, and nearby calls.
- Exports a metadata-only incident report JSON with an ordered request timeline and evidence-backed hypotheses.
- Clearly labels confidence and separates temporal proximity from proven causation.
- No API requests are replayed; request/response payload values and headers are not included in the incident report.
- This is a heuristic assistant, not an automatic root-cause detector. Validate findings against tenant behavior and support logs.


## v2.6.0 — API Recipe Workbench

- Added locally saved environment profiles for variable overrides.
- Dry-run validation resolves `{{variable}}` placeholders using reusable variables and the selected environment.
- Validation checks URL format, unresolved placeholders, JSON payload validity, HTTPS, and non-RUCKUS host warnings.
- Added Postman Collection v2.1 export for saved recipes with an authentication placeholder.
- Environment profiles are included in full backups. The workbench never sends API requests.
- Do not store secrets or live credentials in variable defaults or environment profiles.


## v2.6.0 — Recipe Sequences
- Compose ordered sequences from saved recipe templates.
- Add prerequisites and map output variable names to JSONPath-like expressions from earlier steps.
- Move, remove, save, reload, validate, and export sequences as JSON or Markdown.
- Static validation reports missing variables and malformed output mappings; it does not execute requests or evaluate JSONPath expressions.
- Recipe sequences are included in full backups and project snapshots.


## v2.8.0 — Controlled Recipe Sequence Execution

- Adds a controlled execution panel for saved recipe sequences. Execution is prepared explicitly and each step requires its own review and approval; later steps never run automatically.
- Supports GET, POST, PUT, PATCH, and DELETE to HTTPS hosts under `ruckus.cloud` only. Requests use browser-session credentials where available and do not inject captured authorization headers.
- Captures status, elapsed time, response headers (excluding sensitive header names), and response body in the current side-panel session. Response bodies are capped at 1 MB in the UI state and are not automatically persisted.
- Supports a limited JSONPath-like output mapping (`$.field`, `$.items[0].id`, and quoted property keys) for identifier handoff to later steps. Extracted values are held in memory for the run and must be checked before approving the next step.
- Stops on non-2xx responses, network errors, or output-mapping failures. No automatic retries or automatic progression.
- Safety: review the exact request URL and payload before each step. DELETE and write-like methods are visibly flagged. The host allowlist reduces risk but does not guarantee an operation is harmless.

Execution is an advanced feature. Test read-only recipes first against a non-production tenant. Browser-session authentication may not satisfy every endpoint; the extension intentionally does not harvest or replay Authorization headers from captured traffic.


## v2.8.0 — Execution history and recovery planning

- Stores a metadata-only history of controlled sequence runs (step, recipe name, method, sanitized endpoint path, status, duration, and outcome).
- Persists run summaries locally and includes them in project snapshots and full backups.
- Adds a recovery/rollback planning area linked to a selected execution run. Plans are documentation only; no rollback action is executed or guaranteed to work.
- Exports sanitized history and per-run recovery reports. Request/response bodies, headers, query strings, and runtime variable values are excluded from persisted history.


## v2.9.0 — Capture & Flow Focus

This release narrows the extension to observing API calls in use and understanding their sequence and relationships.

- Simplified navigation to **Live Capture**, **Workflow Flow**, and **API Relationships**.
- Retains live request capture, searchable/filterable timeline, request inspection, performance/troubleshooting observations, heuristic workflow discovery, and captured API relationship/field analysis.
- Removed Recipes, recipe sequences, controlled API sequence execution, execution history, recovery/rollback planning, Documentation Library, Partner Lab Mode, Projects & Backup, reusable variables, and schema/catalog workspaces from the user interface.
- Removed the request-sending implementation used by controlled sequence execution; the extension is intended for observation and analysis, not API playback.
- Removed recipe handoff and Markdown playbook export from workflow discovery. Flow JSON export remains available for analysis.
- No request replay, recipe execution, or automated API write workflow is part of this release.

Workflow grouping and relationship mapping are heuristic: observed order and identifier matches can suggest relationships but do not prove backend causation.


## v2.10.0 — Visual API Flow Map

- Added a visual, horizontally scrollable API flow map to Workflow Flow.
- Displays observed calls as connected nodes with method, status, path, duration, and endpoint interpretation.
- Uses node styling to distinguish read-like calls, write-like calls, and failures/no-response calls.
- Clicking a node switches to Live Capture and opens the matching captured request in Smart API Explorer when the request is still retained.
- Flow windows are based on captured timestamps and the existing 90-second inactivity grouping; arrows show chronological order, not proven server-side dependency.
- No API replay, recipe, or playbook execution was added.


## v2.11.0 — Clear Capture Resets Visual Flow

- Clear Capture now clears the captured request records and the currently rendered Visual API Flow map together.
- The discovered workflow detail list is reset so stale nodes are not left on screen.
- Live capture remains in its current ON/OFF state; performance baselines are not deleted.

## v2.11.0 changes

- Removed the separate Workflow Trace recorder and manual marker workflow.
- Kept Live Capture, Workflow Discovery, Visual API Flow, and API Relationships.


## v2.11.0 cleanup note

- Removed remaining manual action-marker presentation from discovered workflow cards and exports. Workflow Discovery and Visual API Flow continue to derive from live captured requests.
