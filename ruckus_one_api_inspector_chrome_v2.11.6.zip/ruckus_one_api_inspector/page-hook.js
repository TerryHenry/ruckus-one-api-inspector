(() => {
  if (window.__ruckusApiInspectorInstalled) return;
  window.__ruckusApiInspectorInstalled = true;
  const MAX_BODY = 120000;
  let captureEnabled = false;
  window.addEventListener('message', event => {
    if (event.source === window && event.data?.__ruckusApiInspectorCaptureState === true) captureEnabled = !!event.data.enabled;
  });
  const HOST_RE = /(^|\.)(ruckus\.cloud|ruckusone\.com)$/i;
  const SENSITIVE_KEY = /authorization|cookie|token|secret|passw(?:or)?d|passphrase|api[-_]?key|session|jwt|credential|dpsk/i;
  const looksLikeApi = (url, type) => {
    try {
      const u = new URL(url, location.href);
      if (!/^https?:$/.test(u.protocol)) return false;
      if (!HOST_RE.test(u.hostname)) return false;
      // Noise: feature-flag proxy (Split.io) and static assets such as locale bundles / config JSON.
      if (/^splitproxy\./i.test(u.hostname)) return false;
      if (/\/locales\/|\.json$/i.test(u.pathname) && !/\/api\//i.test(u.pathname)) return false;
      if (/\.(js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|map|webp)(\?|$)/i.test(u.href)) return false;
      return type === 'fetch' || type === 'xhr' || /\/api(?:\/|\?|$)|graphql|\/v[0-9]+(?:\/|\?|$)/i.test(u.pathname + u.search);
    } catch { return false; }
  };
  const redactUrl = url => {
    try {
      const u = new URL(url, location.href);
      for (const k of [...u.searchParams.keys()]) if (SENSITIVE_KEY.test(k)) u.searchParams.set(k, '[REDACTED]');
      return u.href;
    } catch { return String(url); }
  };
  const safeHeaders = headers => {
    const out = {};
    try {
      const h = headers instanceof Headers ? headers : new Headers(headers || {});
      h.forEach((v, k) => { out[k] = SENSITIVE_KEY.test(k) ? '[REDACTED]' : v; });
    } catch {}
    return out;
  };
  const maskJson = v => {
    if (Array.isArray(v)) return v.map(maskJson);
    if (v && typeof v === 'object') {
      const o = {};
      for (const [k, x] of Object.entries(v)) o[k] = SENSITIVE_KEY.test(k) ? '[REDACTED]' : maskJson(x);
      return o;
    }
    return v;
  };
  // Fallback for non-JSON or truncated text: key=value / "key":"value" with quoted values that may contain spaces.
  const TEXT_SECRET = /("?[A-Za-z0-9_.-]*(?:authorization|cookie|token|secret|passw(?:or)?d|passphrase|api[-_]?key|session|jwt|credential|dpsk)[A-Za-z0-9_.-]*"?\s*[:=]\s*)(?:"(?:\\.|[^"\\])*"?|[^",}&\s]+)/gi;
  const redactString = s => s.replace(TEXT_SECRET, '$1"[REDACTED]"');
  const clip = value => {
    if (value == null) return null;
    let s = typeof value === 'string' ? value : JSON.stringify(value);
    if (s == null) return null;
    if (s.length <= MAX_BODY) {
      try { return JSON.stringify(maskJson(JSON.parse(s))); } catch {}
      return redactString(s);
    }
    return redactString(s.slice(0, MAX_BODY)) + '… [truncated]';
  };
  const emit = record => {
    if (!captureEnabled) return;
    try { window.postMessage({ __ruckusApiInspector: true, record }, '*'); } catch {}
  };
  const originalFetch = window.fetch;
  window.fetch = async function(input, init) {
    if (!captureEnabled) return originalFetch.apply(this, arguments);
    const started = performance.now();
    const url = typeof input === 'string' || input instanceof URL ? String(input) : input?.url || '';
    const method = String(init?.method || input?.method || 'GET').toUpperCase();
    if (!looksLikeApi(url, 'fetch')) return originalFetch.apply(this, arguments);
    let requestBody = null;
    try { requestBody = clip(init?.body ?? null); } catch {}
    const reqHeaders = safeHeaders(init?.headers || input?.headers);
    const absUrl = redactUrl(url);
    try {
      const response = await originalFetch.apply(this, arguments);
      const finish = responseBody => emit({ timestamp: new Date().toISOString(), url: absUrl, method, status: response.status, statusText: response.statusText, durationMs: Math.round(performance.now() - started), requestHeaders: reqHeaders, requestBody, responseHeaders: safeHeaders(response.headers), responseBody, source: 'fetch', pageUrl: location.href });
      const ct = response.headers.get('content-type') || '';
      if (/event-stream/i.test(ct) || !/json|text|xml|graphql/i.test(ct)) {
        finish(null);
      } else {
        // Never block the page: read the clone in the background and emit when it completes.
        let clone = null;
        try { clone = response.clone(); } catch {}
        if (!clone) finish('[Could not read response body]');
        else clone.text().then(t => finish(clip(t)), () => finish('[Could not read response body]'));
      }
      return response;
    } catch (error) {
      emit({ timestamp: new Date().toISOString(), url: absUrl, method, status: 0, statusText: String(error), durationMs: Math.round(performance.now() - started), requestHeaders: reqHeaders, requestBody, responseHeaders: {}, responseBody: null, source: 'fetch', pageUrl: location.href });
      throw error;
    }
  };
  const XHR = window.XMLHttpRequest;
  const open = XHR.prototype.open, send = XHR.prototype.send, setHeader = XHR.prototype.setRequestHeader;
  XHR.prototype.open = function(method, url) { this.__ri = { method: String(method || 'GET').toUpperCase(), url: String(url), headers: {}, started: 0 }; return open.apply(this, arguments); };
  XHR.prototype.setRequestHeader = function(k, v) { if (this.__ri) this.__ri.headers[k] = SENSITIVE_KEY.test(k) ? '[REDACTED]' : String(v); return setHeader.apply(this, arguments); };
  XHR.prototype.send = function(body) {
    const info = this.__ri;
    if (captureEnabled && info && looksLikeApi(info.url, 'xhr')) {
      info.started = performance.now(); info.body = clip(body);
      this.addEventListener('loadend', () => {
        let responseBody = null;
        try { if (typeof this.responseText === 'string') responseBody = clip(this.responseText); else if (this.response != null) responseBody = clip(this.response); } catch {}
        const headers = {};
        try { this.getAllResponseHeaders().trim().split(/[\r\n]+/).filter(Boolean).forEach(line => { const i = line.indexOf(':'); if (i > 0) { const k = line.slice(0, i).trim(); headers[k] = SENSITIVE_KEY.test(k) ? '[REDACTED]' : line.slice(i + 1).trim(); } }); } catch {}
        try { emit({ timestamp: new Date().toISOString(), url: redactUrl(info.url), method: info.method, status: this.status, statusText: this.statusText, durationMs: Math.round(performance.now() - info.started), requestHeaders: info.headers, requestBody: info.body, responseHeaders: headers, responseBody, source: 'xhr', pageUrl: location.href }); } catch {}
      }, { once: true });
    }
    return send.apply(this, arguments);
  };
})();
