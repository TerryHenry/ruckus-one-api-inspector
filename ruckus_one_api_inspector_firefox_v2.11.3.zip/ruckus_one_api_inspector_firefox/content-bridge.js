(() => {
  const applyCaptureState = enabled => window.postMessage({ __ruckusApiInspectorCaptureState: true, enabled: !!enabled }, '*');
  chrome.runtime.onMessage.addListener(message => { if (message?.type === 'SET_PAGE_CAPTURE') applyCaptureState(message.enabled); });
  try { chrome.runtime.sendMessage({ type: 'GET_CAPTURE_STATUS' }, response => { if (!chrome.runtime.lastError) applyCaptureState(response?.enabled); }); } catch {}
  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.__ruckusApiInspector !== true || !event.data.record) return;
    try { chrome.runtime.sendMessage({ type: 'API_CAPTURE', record: event.data.record }); } catch {}
  });
})();
