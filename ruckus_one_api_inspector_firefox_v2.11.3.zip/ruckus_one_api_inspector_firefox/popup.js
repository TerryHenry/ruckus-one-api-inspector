const $ = id => document.getElementById(id);
let allRecords = [], expanded = new Set();
const pathKey = url => { try { const u = new URL(url); return u.origin + u.pathname; } catch { return url; } };
const safeRecord = r => ({...r, requestHeaders: redactObject(r.requestHeaders), responseHeaders: redactObject(r.responseHeaders), requestBody: redactText(r.requestBody), responseBody: redactText(r.responseBody)});
function redactText(v) { if (typeof v !== 'string') return v; return v.replace(/("?(?:access_token|refresh_token|client_secret|password|api_key|apiKey|authorization|cookie|session_token)"?\s*[:=]\s*)"?[^",}\s]+"?/gi, '$1"[REDACTED]"'); }
function redactObject(o) { const out={}; for(const [k,v] of Object.entries(o||{})) out[k]=/authorization|cookie|token|secret|api[-_]?key|session/i.test(k)?'[REDACTED]':v; return out; }
function render() {
 const q=$('search').value.toLowerCase(), m=$('method').value;
 const filtered=allRecords.slice().reverse().filter(r=>(!m||r.method===m)&&(!q||`${r.method} ${r.url} ${r.status} ${r.statusText}`.toLowerCase().includes(q)));
 $('total').textContent=allRecords.length; $('unique').textContent=new Set(allRecords.map(r=>`${r.method} ${pathKey(r.url)}`)).size; $('errors').textContent=allRecords.filter(r=>!r.status||r.status>=400).length;
 const root=$('requests'); root.innerHTML='';
 if(!filtered.length){root.innerHTML='<div class="empty">No matching requests.<br><small>Navigate to another screen in RUCKUS One to discover more endpoints.</small></div>';return;}
 for(const r of filtered){const key=`${r.timestamp}|${r.method}|${r.url}`;const item=document.createElement('div');item.className='item';const line=document.createElement('div');line.className='line1';const method=document.createElement('span');method.className=`method ${r.method}`;method.textContent=r.method;const url=document.createElement('div');url.className='url';url.textContent=r.url;const status=document.createElement('span');status.className='status';status.textContent=`${r.status||'ERR'} · ${r.durationMs??'?'} ms`;line.append(method,status);item.append(line,url);const meta=document.createElement('div');meta.className='meta';meta.textContent=`${r.timestamp||''} · ${r.source||''} · ${r.statusText||''}`;item.append(meta);
 if(expanded.has(key)){const d=document.createElement('div');d.className='detail';d.textContent=JSON.stringify(safeRecord(r),null,2);item.append(d);} item.addEventListener('click',()=>{expanded.has(key)?expanded.delete(key):expanded.add(key);render();});root.append(item);
 }
}
function download(name, type, text){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);chrome.downloads.download({url,filename:name,saveAs:true},()=>setTimeout(()=>URL.revokeObjectURL(url),5000));}
function exportJson(){download('ruckus-one-api-capture.json','application/json',JSON.stringify({exportedAt:new Date().toISOString(),tool:'RUCKUS One API Inspector',version:'0.1.0',records:allRecords.map(safeRecord)},null,2));}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
function exportCsv(){const fields=['timestamp','method','url','status','statusText','durationMs','source','pageUrl','requestHeaders','requestBody','responseHeaders','responseBody'];const rows=[fields.join(','),...allRecords.map(r=>fields.map(k=>csvCell(typeof r[k]==='object'?JSON.stringify(redactObject(r[k])):typeof r[k]==='string'?redactText(r[k]):r[k])).join(','))];download('ruckus-one-api-capture.csv','text/csv;charset=utf-8',rows.join('\r\n'));}
async function load(){const result=await chrome.runtime.sendMessage({type:'GET_RECORDS'});allRecords=result?.records||[];render();}
$('search').addEventListener('input',render);$('method').addEventListener('change',render);$('exportJson').addEventListener('click',exportJson);$('exportCsv').addEventListener('click',exportCsv);$('clear').addEventListener('click',async()=>{if(confirm('Delete all captured API records?')){await chrome.runtime.sendMessage({type:'CLEAR_RECORDS'});allRecords=[];expanded.clear();render();}});load();chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.ruckusApiInspectorRecords){allRecords=changes.ruckusApiInspectorRecords.newValue||[];render();}});
