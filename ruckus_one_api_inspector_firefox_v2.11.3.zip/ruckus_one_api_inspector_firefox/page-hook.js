(() => {
  if (window.__ruckusApiInspectorInstalled) return;
  window.__ruckusApiInspectorInstalled = true;
  const MAX_BODY = 120000;
  let captureEnabled = false;
  window.addEventListener('message', event => {
    if (event.source === window && event.data?.__ruckusApiInspectorCaptureState === true) captureEnabled = !!event.data.enabled;
  });
  const looksLikeApi = (url, type) => {
    try {
      const u = new URL(url, location.href);
      if (!/^https?:$/.test(u.protocol)) return false;
      if (/\.(js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|map|webp)(\?|$)/i.test(u.href)) return false;
      return type === 'fetch' || type === 'xhr' || /\/api(?:\/|\?|$)|graphql|\/v[0-9]+(?:\/|\?|$)/i.test(u.pathname + u.search);
    } catch { return false; }
  };
  const safeHeaders = headers => {
    const out = {};
    try {
      const h = headers instanceof Headers ? headers : new Headers(headers || {});
      h.forEach((v, k) => { out[k] = /authorization|cookie|token|secret|api[-_]?key|session/i.test(k) ? '[REDACTED]' : v; });
    } catch {}
    return out;
  };
  const clip = value => {
    if (value == null) return null;
    let s = typeof value === 'string' ? value : JSON.stringify(value);
    if (s.length > MAX_BODY) s = s.slice(0, MAX_BODY) + '… [truncated]';
    // Best-effort redact common secret fields in JSON/text payloads.
    s = s.replace(/("?(?:access_token|refresh_token|client_secret|password|api_key|apiKey|authorization|cookie|session_token)"?\s*[:=]\s*)"?[^",}\s]+"?/gi, '$1"[REDACTED]"');
    return s;
  };
  const emit = record => {
    if (!captureEnabled) return;
    try { window.postMessage({ __ruckusApiInspector: true, record }, '*'); } catch {}
  };
  const originalFetch = window.fetch;
  window.fetch = async function(input, init) {
    if (!captureEnabled) return originalFetch.apply(this, arguments);
    const started = performance.now();
    const url = typeof input === 'string' || input instanceof URL ? String(input) : input?.url || '';
    const method = String(init?.method || input?.method || 'GET').toUpperCase();
    if (!looksLikeApi(url, 'fetch')) return originalFetch.apply(this, arguments);
    let requestBody = null;
    try { requestBody = clip(init?.body ?? null); } catch {}
    const reqHeaders = safeHeaders(init?.headers || input?.headers);
    try {
      const response = await originalFetch.apply(this, arguments);
      let responseBody = null;
      try {
        const ct = response.headers.get('content-type') || '';
        if (/json|text|xml|graphql/i.test(ct)) responseBody = clip(await response.clone().text());
      } catch (e) { responseBody = '[Could not read response body]'; }
      emit({ timestamp: new Date().toISOString(), url: new URL(url, location.href).href, method, status: response.status, statusText: response.statusText, durationMs: Math.round(performance.now() - started), requestHeaders: reqHeaders, requestBody, responseHeaders: safeHeaders(response.headers), responseBody, source: 'fetch', pageUrl: location.href });
      return response;
    } catch (error) {
      emit({ timestamp: new Date().toISOString(), url: new URL(url, location.href).href, method, status: 0, statusText: String(error), durationMs: Math.round(performance.now() - started), requestHeaders: reqHeaders, requestBody, responseHeaders: {}, responseBody: null, source: 'fetch', pageUrl: location.href });
      throw error;
    }
  };
  const XHR = window.XMLHttpRequest;
  const open = XHR.prototype.open, send = XHR.prototype.send, setHeader = XHR.prototype.setRequestHeader;
  XHR.prototype.open = function(method, url) { this.__ri = { method: String(method || 'GET').toUpperCase(), url: String(url), headers: {}, started: 0 }; return open.apply(this, arguments); };
  XHR.prototype.setRequestHeader = function(k, v) { if (this.__ri) this.__ri.headers[k] = /authorization|cookie|token|secret|api[-_]?key|session/i.test(k) ? '[REDACTED]' : String(v); return setHeader.apply(this, arguments); };
  XHR.prototype.send = function(body) {
    const info = this.__ri;
    if (captureEnabled && info && looksLikeApi(info.url, 'xhr')) {
      info.started = performance.now(); info.body = clip(body);
      this.addEventListener('loadend', () => {
        let responseBody = null;
        try { if (typeof this.responseText === 'string') responseBody = clip(this.responseText); else if (this.response != null) responseBody = clip(this.response); } catch {}
        const headers = {};
        try { this.getAllResponseHeaders().trim().split(/[\r\n]+/).filter(Boolean).forEach(line => { const i = line.indexOf(':'); if (i > 0) { const k = line.slice(0, i).trim(); headers[k] = /set-cookie|token|secret|authorization/i.test(k) ? '[REDACTED]' : line.slice(i + 1).trim(); } }); } catch {}
        try { emit({ timestamp: new Date().toISOString(), url: new URL(info.url, location.href).href, method: info.method, status: this.status, statusText: this.statusText, durationMs: Math.round(performance.now() - info.started), requestHeaders: info.headers, requestBody: info.body, responseHeaders: headers, responseBody, source: 'xhr', pageUrl: location.href }); } catch {}
      }, { once: true });
    }
    return send.apply(this, arguments);
  };
})();
