const KEY = 'ruckusApiInspectorRecords';
const CAPTURE_KEY = 'ruckusApiInspectorCaptureEnabled';
const MAX_RECORDS = 5000;
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get({ [CAPTURE_KEY]: null }, data => { if (data[CAPTURE_KEY] === null) chrome.storage.local.set({ [CAPTURE_KEY]: false }); });
  if (chrome.sidePanel?.setPanelBehavior) chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.runtime.onStartup?.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'API_CAPTURE' && message.record) {
    chrome.storage.local.get({ [CAPTURE_KEY]: false, [KEY]: [] }, data => {
      if (!data[CAPTURE_KEY]) return;
      const records = data[KEY] || [];
      records.push({ ...message.record, tabId: sender.tab?.id ?? null });
      if (records.length > MAX_RECORDS) records.splice(0, records.length - MAX_RECORDS);
      chrome.storage.local.set({ [KEY]: records });
    });
    return;
  }
  if (message?.type === 'GET_CAPTURE_STATUS') {
    chrome.storage.local.get({ [CAPTURE_KEY]: false }, data => sendResponse({ enabled: !!data[CAPTURE_KEY] }));
    return true;
  }
  if (message?.type === 'SET_CAPTURE') {
    const enabled = !!message.enabled;
    chrome.storage.local.set({ [CAPTURE_KEY]: enabled }, () => {
      chrome.tabs.query({ url: ['https://*.ruckus.cloud/*', 'https://*.ruckusone.com/*'] }, tabs => {
        for (const tab of tabs) if (tab.id != null) chrome.tabs.sendMessage(tab.id, { type: 'SET_PAGE_CAPTURE', enabled }).catch(() => {});
      });
      sendResponse({ ok: true, enabled });
    });
    return true;
  }
  if (message?.type === 'GET_RECORDS') {
    chrome.storage.local.get({ [KEY]: [] }, data => sendResponse({ records: data[KEY] || [] }));
    return true;
  }
  if (message?.type === 'CLEAR_RECORDS') {
    chrome.storage.local.set({ [KEY]: [] }, () => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === 'OPEN_SIDE_PANEL' && sender.tab?.id != null && chrome.sidePanel?.open) {
    chrome.sidePanel.open({ tabId: sender.tab.id }).then(() => sendResponse({ok:true})).catch(error => sendResponse({ok:false,error:String(error)}));
    return true;
  }
});

// Firefox sidebar support (Chrome uses the manifest side_panel configuration).
if (typeof browser !== 'undefined' && browser.sidebarAction && browser.action) { browser.action.onClicked.addListener(() => browser.sidebarAction.open()); }
